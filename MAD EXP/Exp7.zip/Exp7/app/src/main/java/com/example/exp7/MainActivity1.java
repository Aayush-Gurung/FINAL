package com.example.exp7;

import android.os.Bundle;

public interface MainActivity1 {

}
