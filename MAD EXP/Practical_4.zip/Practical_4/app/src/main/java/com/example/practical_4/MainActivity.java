package com.example.practical_4;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button youtube;
    TextView surprise;
    ImageView facebook;
    ImageView instagram;
    private Button button2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        youtube = findViewById(R.id.youtube);
        surprise = findViewById(R.id.surprise);
        facebook = findViewById(R.id.facebook);
        instagram = findViewById(R.id.instagram);
        button2 = (Button) findViewById(R.id.button2);

        youtube.setOnClickListener(view -> gotoUrl("https://www.youtube.com/"));

        surprise.setOnClickListener(view -> gotoUrl("https://gifer.com/en/gifs/surprise"));

        facebook.setOnClickListener(view -> gotoUrl("https://www.facebook.com/"));

        instagram.setOnClickListener(view -> gotoUrl("https://www.instagram.com/"));

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2();
            }
        });
    }

    public void openActivity2(){
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

    }
}